/*
 * DARK OWNER ADMIN SERVER
 * Crafted with passion & dedication.
 * Original Credits: DARK OWNER ADMIN SERVER
 * Telegram: @DARK_OWNER_VIP
 * Private Source & Support: DM @DARK_OWNER_VIP
 * Proudly Made for India
 */

#pragma once

#include "include/input.h"
#include "include/java.h"

struct ButtonClicker {
    bool Active = false;
    float ElapsedTime = 0.f;
    float HoldDuration = 0.15f;
    ImVec2 ClickPos;
    int TouchIndex = 11;

    enum State {
        IDLE,
        PRESSING,
    } state = IDLE;

    void Click(ImVec2 pos, float duration = 0.15f) {
        if (this->Active) return;

        this->ClickPos = pos;
        this->HoldDuration = duration;
        this->ElapsedTime = 0.f;
        this->Active = true;
        this->state = PRESSING;

        JNIThreadScope jni;
        if (!jni.env) return;
        NativeTouchesBegin(jni.env, this->TouchIndex, this->ClickPos.x, this->ClickPos.y);
    }

    void Update() {
        if (!this->Active) return;

        float dt = ImGui::GetIO().DeltaTime;

        if (this->state == PRESSING) {
            this->ElapsedTime += dt;

            if (dynamic_bool["DebugTouch"]) {
                ImDrawList* fg = ImGui::GetForegroundDrawList();
                fg->AddCircleFilled(this->ClickPos, 15.0f, IM_COL32(255, 255, 255, 100));
                fg->AddCircle(this->ClickPos, 15.0f, IM_COL32(255, 255, 255, 200), 0.0f, 2.0f);
            }

            if (this->ElapsedTime >= this->HoldDuration) {
                JNIThreadScope jni;
                if (jni.env) NativeTouchesEnd(jni.env, this->TouchIndex, this->ClickPos.x, this->ClickPos.y);
                this->Active = false;
                this->state = IDLE;
            }
        }
    }
};

ButtonClicker buttonClicker;
