// Hook-target sanity check and a status line shown in the overlay.
#pragma once
#include <atomic>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <sys/mman.h>
#include <unistd.h>

// Short text shown in the "Colors" panel so the state is visible without logcat.
inline char g_hookStatus[192] = "hooks: not started";
inline char g_touchStatus[128] = "touch: not installed";
// True only after every game hook was installed. Features that read game state stay disabled until then.
inline std::atomic<bool> g_gameHooksOk{false};

// True when the 32-bit word at `addr` can plausibly be the first instruction of an AArch64 function.
// Rejects the opcodes a function can never start with: ret, bl, b.cond, and load-pair (epilogue).
// A leaf function may still start with any other instruction, so this only catches blatant mismatches;
// it is not proof that the address is the intended function.
inline bool DragonInsnCanStartFunction(uint32_t w) {
    if (w == 0xD65F03C0u) return false;               // ret
    if ((w & 0xFC000000u) == 0x94000000u) return false; // bl
    if ((w & 0xFF000010u) == 0x54000000u) return false; // b.cond
    if ((w & 0x3FC00000u) == 0x28C00000u || (w & 0x3FC00000u) == 0x29400000u ||
        (w & 0x3FC00000u) == 0x28400000u) return false;  // ldp (post-index / signed offset / no-alloc)
    return true;
}

// Reads one instruction word at `addr` only if its page is mapped.
inline bool DragonReadWord(uintptr_t addr, uint32_t* out) {
    const long ps = sysconf(_SC_PAGESIZE);
    if (ps <= 0 || (addr & 3u)) return false;
    unsigned char vec = 0;
    if (mincore(reinterpret_cast<void*>(addr & ~static_cast<uintptr_t>(ps - 1)), 1, &vec) != 0) return false;
    memcpy(out, reinterpret_cast<const void*>(addr), sizeof(*out));
    return true;
}
